import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../model/products.dart';

class product extends StatefulWidget {
  //final Products products;
  product(List<Products>? products, this.index)
      : this.products = products ?? [];
  final List<Products> products;
  final int index;

  @override
  State<product> createState() => _productState();
}

class _productState extends State<product> {
  var isLoad = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (widget.products != null) {
      setState(() {
        isLoad = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Visibility(
      replacement: const Center(child: CircularProgressIndicator()),
      visible: isLoad,
      child: Sizer(builder: (context, orientation, deviceType) {
        return Stack(
          children: [
            Container(
              height: 45.h,
              child: widget.products![widget.index].image == ""
                  ? Image.asset("asset/index.png")
                  : Image.network(widget.products![widget.index].image),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: 60.h,
                width: 100.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(3.h),
                      topRight: Radius.circular(3.h),
                    )),
                alignment: Alignment.bottomCenter,
                child: SingleChildScrollView(
                  child: Container(margin: EdgeInsets.only(top: 9.h,left: 2.h,right: 2.h),
                    child: Column(
                      children: [
                        makeColumn(key1: widget.products![widget.index].name, value: "نام محصول:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                        makeColumn(key1: widget.products![widget.index].regularPrice, value: "قیمت عادی:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                        makeColumn(key1: widget.products![widget.index].price, value: "قیمت با تخفیف:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                        makeColumn(key1: widget.products![widget.index].stockQuantity, value: "موجودی انبار:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                        makeColumn(key1: widget.products![widget.index].dateOnSaleFrom, value: "تاریخ شروع تخفیف:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                        makeColumn(key1: widget.products![widget.index].dateOnSaleTo, value: "تاریخ پایان تخفیف:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                        makeColumn(key1: widget.products![widget.index].lowStock, value: "تعداد کف انبار:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                        makeColumn(key1: widget.products![widget.index].sku, value: "SKU:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                        makeColumn(key1: widget.products![widget.index].totalSales.toString(), value: "تعداد فروش کل:"),
                        Container(padding: EdgeInsets.only(),child: Divider()),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Container(
              //color: Colors.blueGrey,
              margin: EdgeInsets.only(top: 34.h, left: 7.w, right: 2.w),
              height: 12.h,
              width: 85.w,
              child: Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(1.5.h)),
                elevation: 2.w,
                child: Container(
                  height: 0.05.h,
                  width: 0.02.w,
                  padding: EdgeInsets.all(1.5.h),
                  child: widget.products![widget.index].image == ""
                      ? Image.asset("asset/index.png")
                      : Image.network(widget.products![widget.index].image),
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
}class makeColumn extends StatelessWidget {
  final String key1;
  final String value;

  const makeColumn({
    Key? key,
    required this.key1,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(margin: EdgeInsets.all(0.5.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Container(
              width: 45.w,
              child: key1 != "" ? Row(
                children: [
                  Container(child: Icon(Icons.edit,color: Colors.grey.shade600,)),
                  Center(
                    child: Container(alignment: Alignment.center,width: 38.w,
                      child: Text(
                        key1,
                        style: TextStyle(fontFamily: "IRANSansWeb",decoration: TextDecoration.none,color: Colors.grey.shade600,fontSize: 1.5.h),
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.rtl,
                      ),
                    ),
                  ),
                ],
              ):Text("-",style: TextStyle(decoration: TextDecoration.none,fontSize: 1.5.h,color: Colors.grey.shade600) ,textAlign: TextAlign.center,)),
          Container(
              width: 45.w,
              child: Text(
                value,
                style: TextStyle(fontFamily: "IRANSansWeb",decoration: TextDecoration.none,color: Colors.grey.shade600,fontSize: 2.h),
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
              )),
        ],
      ),
    );
  }
}
